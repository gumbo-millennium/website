<?php

declare(strict_types=1);

namespace Laravel\Nova;

use Illuminate\Support\ServiceProvider;

class UselessServiceProvider extends ServiceProvider
{
    public function boot()
    {
	    // noop
    }

    public function register()
    {
	    // noop
    }
}
