PHP library for Google Pay Passes API v1



Requirements:

Google API PHP Client, version 1.1.1
URL: https://github.com/google/google-api-php-client/releases

