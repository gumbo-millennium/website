<?php

namespace Sloveniangooner\SearchableSelect\Http\Middleware;

class Authorize
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return \Illuminate\Http\Response
     */
    public function handle($request, $next)
    {
        return $next($request);
    }
}
